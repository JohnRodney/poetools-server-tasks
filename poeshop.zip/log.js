module.exports = {
  log: console,
};
