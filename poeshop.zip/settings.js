module.exports = {
  mongoConnectionString: 'mongodb://xenoraphorze:zerojiggy@cluster1-shard-00-00-ckpu4.mongodb.net:27017,cluster1-shard-00-01-ckpu4.mongodb.net:27017,cluster1-shard-00-02-ckpu4.mongodb.net:27017/Cluster1?ssl=true&replicaSet=Cluster1-shard-0&authSource=admin',
};
